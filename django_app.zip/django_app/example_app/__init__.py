"""
Package for the application.
"""